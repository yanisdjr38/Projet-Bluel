# Portfolio-architecte-sophie-bluel

Code du projet 6 d'intégrateur web.

## Architecture

Ce repo git contient les 2 briques logicielles du projet 
- Frontend
- Backend

## Pour le lancer le code
### Backend
Ouvrir le dossier Backend et lire le README.md

### Frontend
Ouvrir le dossier Frontend et lancer liveserver de votre IDE
 
## Astuce
 
Si vous désirez afficher le code du backend et du frontend, faites le dans 2 instances de VSCode différentes pour éviter tout problème
